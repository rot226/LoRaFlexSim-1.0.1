# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-06-19
- Initial public release of the Python based LoRa network simulator.
