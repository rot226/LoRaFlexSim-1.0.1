import pytest

pytest.skip("panel not available in test environment", allow_module_level=True)

